/*
 * University of Warsaw
 * Concurrent Programming Course 2023/2024
 * Java Assignment
 *
 * Author: Jakub Adamiak (ja429126@students.mimuw.edu.pl)
 */
package cp2023.solution;

import cp2023.base.*;
import cp2023.exceptions.*;

import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.*;

public class StorageSystemImpl implements StorageSystem {
    private ReentrantLock lock;
    private HashMap<DeviceId, Device> devices;
    private HashMap<ComponentId, Component> components;

    public StorageSystemImpl(Map<DeviceId, Integer> deviceCapacities, Map<ComponentId, DeviceId> componentPlacement) {
        devices = new HashMap<DeviceId, Device>();
        components = new HashMap<ComponentId, Component>();
        lock = new ReentrantLock();

        // Create a device list
        for (Map.Entry<DeviceId, Integer> entry : deviceCapacities.entrySet()) {
            devices.put(entry.getKey(), new Device(entry.getKey(), entry.getValue()));
        }

        // Place components on their respective devices
        for (Map.Entry<ComponentId, DeviceId> entry : componentPlacement.entrySet()) {
            ComponentId compId = entry.getKey();
            DeviceId devId = entry.getValue();
            Device device = devices.get(devId);
            Component newComponent = new Component(compId, devId);
            newComponent.setFieldNumber(device.findFirstFreeFieldIndex());
            device.addComponent();
            components.put(compId, newComponent);
        }
    }

    @Override
    public void execute(ComponentTransfer transfer) throws TransferException {
        // Execute the transfer from the beginning to the end
        try {
            lock.lock();
            try {
                validateTransfer(transfer);
                doTheTransfer1(transfer);
            } finally {
                lock.unlock();
            }
            transfer.prepare();
            lock.lock();
            try {
                doTheTransfer2(transfer);
            } finally {
                lock.unlock();
            }
            transfer.perform();
            lock.lock();
            try {
                if (components.get(transfer.getComponentId()).getDeviceId() == null)
                    components.remove(transfer.getComponentId());
                else {
                    components.get(transfer.getComponentId()).markAsNotBeingTransferred();
                }
            } finally {
                lock.unlock();
            }
        } catch (TransferException e) {
            throw e;
        } catch (InterruptedException | BrokenBarrierException e) {
            throw new RuntimeException("panic: unexpected thread interruption", e);
        }
    }

    private void validateTransfer(ComponentTransfer transfer) throws IllegalTransferType, DeviceDoesNotExist,
            ComponentAlreadyExists, ComponentDoesNotExist, ComponentDoesNotNeedTransfer, ComponentIsBeingOperatedOn {
        // Perform various checks to ensure validity of the transfer
        DeviceId srcDeviceId = transfer.getSourceDeviceId();
        DeviceId dstDeviceId = transfer.getDestinationDeviceId();
        ComponentId componentId = transfer.getComponentId();

        if (srcDeviceId != null && !devices.containsKey(srcDeviceId)) {
            throw new DeviceDoesNotExist(srcDeviceId);
        }
        if (dstDeviceId != null && !devices.containsKey(dstDeviceId)) {
            throw new DeviceDoesNotExist(dstDeviceId);
        }

        if (srcDeviceId == null && componentId != null)
            if (components.containsKey(componentId))
                throw new ComponentAlreadyExists(componentId, components.get(componentId).getDeviceId());

        if (componentId == null || (srcDeviceId == null && dstDeviceId == null))
            throw new IllegalTransferType(componentId);

        if (components.get(componentId) == null && (srcDeviceId != null && devices.get(srcDeviceId) != null))
            throw new ComponentDoesNotExist(componentId, srcDeviceId);

        Component currComponent = components.get(componentId) == null ? new Component(componentId, null) : components.get(componentId);

        if (srcDeviceId != null && !currComponent.getDeviceId().equals(srcDeviceId)) {
            throw new ComponentDoesNotExist(componentId, srcDeviceId);
        }

        if (currComponent.isBeingTransferred()) {
            throw new ComponentIsBeingOperatedOn(componentId);
        }

        if (dstDeviceId != null && currComponent.getDeviceId() != null && currComponent.getDeviceId().equals(dstDeviceId)) {
            throw new ComponentDoesNotNeedTransfer(componentId, dstDeviceId);
        }

        currComponent.markAsBeingTransferred();
    }

    private int findCycle(HashSet<DeviceId> visited, Device currDevice, int currField, Device dstDevice) {
        // Search for a cycle in our graph of transfers, utilizing DFS algorithm
        if (currDevice == dstDevice) {
            return currField;
        }
        if (visited.contains(currDevice.getDeviceID()))
            return -1;
        visited.add(currDevice.getDeviceID());

        for (Component c : currDevice.getQueue()) {
            Device d = devices.get(c.getDeviceId());
            if (d == null) {
                continue;
            }
            int f = c.getFieldNumber();
            int res = findCycle(visited, d, f, dstDevice);
            if (res != -1) {
                c.setDstFieldNumber(currField);
                currDevice.getQueue().remove(c);
                c.getTransferCondition().signal();
                return res;
            }
        }

        return -1;
    }


    private void doTheTransfer1(ComponentTransfer transfer) throws InterruptedException, BrokenBarrierException {
        // Handle first part of the transfer, until prepare()
        ComponentId currComponentId = transfer.getComponentId();
        if (components.get(currComponentId) == null) {
            components.put(currComponentId, new Component(currComponentId, null));
            components.get(currComponentId).markAsBeingTransferred();
        }
        Component currComponent = components.get(currComponentId);
        DeviceId currDstDeviceId = transfer.getDestinationDeviceId();
        Device currDstDevice = devices.get(currDstDeviceId);
        DeviceId currSrcDeviceId = transfer.getSourceDeviceId();
        Device currSrcDevice = currSrcDeviceId == null ? null : devices.get(currSrcDeviceId);

        if (currDstDevice == null || !currDstDevice.getImmediateTransferList().isEmpty()) {
            int currDstField;

            if (currDstDevice == null)
                currDstField = 0;
            else {
                currDstField = currDstDevice.getImmediateTransferList()
                        .get(currDstDevice.getImmediateTransferList().size() - 1);
                currDstDevice.getImmediateTransferList().remove(currDstDevice.getImmediateTransferList().size() - 1);
            }
            currComponent.setDstFieldNumber(currDstField);

            Device d = currSrcDevice;
            int f = currComponent.fieldNumber;
            while (d != null && !d.getQueue().isEmpty()) {
                Component c = d.getQueue().removeFirst();
                c.setDstFieldNumber(f);
                d = devices.get(c.getDeviceId()); // !!
                f = c.getFieldNumber();
                c.getTransferCondition().signal();
            }
            if (d != null)
                d.getImmediateTransferList().add(f);
        } else if (currSrcDevice != null && currDstDevice != null) {
            HashSet<DeviceId> visited = new HashSet<>();
            currComponent.setDstFieldNumber(findCycle(visited, currSrcDevice, currComponent.getFieldNumber(), currDstDevice));
        }

        if (currComponent.getDstFieldNumber() == -1) {
            currDstDevice.getQueue().addLast(currComponent);
            do {
                currComponent.getTransferCondition().await();
            } while (currComponent.getDstFieldNumber() == -1);
        }
    }

    private void doTheTransfer2(ComponentTransfer transfer) throws InterruptedException, BrokenBarrierException {
        // Handle second part of the transfer, after prepare(), until perform()
        ComponentId currComponentId = transfer.getComponentId();
        if (components.get(currComponentId) == null) {
            components.put(currComponentId, new Component(currComponentId, null));
            components.get(currComponentId).markAsBeingTransferred();
        }
        Component currComponent = components.get(currComponentId);
        DeviceId currDstDeviceId = transfer.getDestinationDeviceId();
        Device currDstDevice = devices.get(currDstDeviceId);
        DeviceId currSrcDeviceId = transfer.getSourceDeviceId();
        Device currSrcDevice = currSrcDeviceId == null ? null : devices.get(currSrcDeviceId);

        if (currSrcDevice != null) {
            currSrcDevice.getOccupied()[currComponent.getFieldNumber()].set(false);
            currSrcDevice.getFieldConditions()[currComponent.getFieldNumber()].signal();
        }

        if (currDstDevice != null) {
            while (currDstDevice.getOccupied()[currComponent.getDstFieldNumber()].get())
                currDstDevice.getFieldConditions()[currComponent.getDstFieldNumber()].await();
            currDstDevice.getOccupied()[currComponent.getDstFieldNumber()].set(true);
        }

        currComponent.setFieldNumber(currComponent.getDstFieldNumber());
        currComponent.setDeviceId(currDstDeviceId);
        currComponent.setDstFieldNumber(-1);
    }



    private class Device {
        private DeviceId deviceId;
        private AtomicBoolean[] occupied;
        private Condition[] fieldConditions;
        private ArrayList<Integer> immediateTransferList;
        private LinkedList<Component> queue;
        int capacity;

        public Device(DeviceId deviceId, int capacity) {
            this.capacity = capacity;
            this.deviceId = deviceId;
            this.occupied = new AtomicBoolean[capacity];
            this.fieldConditions = new Condition[capacity];
            this.immediateTransferList = new ArrayList<>();
            this.queue = new LinkedList<>();

            for (int i = 0; i < capacity; i++) {
                occupied[i] = new AtomicBoolean(false);
                fieldConditions[i] = lock.newCondition();
                immediateTransferList.add(i);
            }
        }

        public LinkedList<Component> getQueue() {
            return queue;
        }

        public List<Integer> getImmediateTransferList() {
            return this.immediateTransferList;
        }

        public AtomicBoolean[] getOccupied() {
            return this.occupied;
        }

        public Condition[] getFieldConditions() {
            return this.fieldConditions;
        }

        public int findFirstFreeFieldIndex() {
            for (int i = 0; i < capacity; i++)
                if (!this.occupied[i].get())
                    return i;
            return -1;
        }

        public void addComponent() {
            int ind = -1;
            for (int i = 0; i < capacity; i++)
                if (!this.occupied[i].get()) {
                    ind = i;
                    break;
                }
            if (ind >= 0)
                this.occupied[ind].set(true);

            this.immediateTransferList.remove(0);
        }

        public DeviceId getDeviceID() {
            return this.deviceId;
        }
    }

    private class Component {
        private ComponentId componentId;
        private DeviceId deviceId;
        private int fieldNumber;
        private int dstFieldNumber;
        private boolean isBeingTransferred;
        private final Condition transferCondition;

        public Component(ComponentId componentId, DeviceId deviceId) {
            this.componentId = componentId;
            this.deviceId = deviceId;
            this.transferCondition = lock.newCondition();
            this.fieldNumber = -1;
            this.dstFieldNumber = -1;
            this.isBeingTransferred = false;
        }

        public void setFieldNumber(int fieldNumber) {
            this.fieldNumber = fieldNumber;
        }

        public int getFieldNumber() {
            return this.fieldNumber;
        }

        public int getDstFieldNumber() {
            return this.dstFieldNumber;
        }

        public void setDstFieldNumber(int fieldNumber) {
            this.dstFieldNumber = fieldNumber;
        }

        public void markAsBeingTransferred() {
            this.isBeingTransferred = true;
        }

        public void markAsNotBeingTransferred() {
            this.isBeingTransferred = false;
        }

        public boolean isBeingTransferred() {
            return this.isBeingTransferred;
        }

        public Condition getTransferCondition() {
            return this.transferCondition;
        }

        public DeviceId getDeviceId() {
            return this.deviceId;
        }

        public void setDeviceId(DeviceId d) {
            this.deviceId = d;
        }
    }

}
