/*
 * University of Warsaw
 * Concurrent Programming Course 2023/2024
 * Java Assignment
 *
 * Authors: Konrad Iwanicki (iwanicki@mimuw.edu.pl),
 *          Jakub Adamiak (ja429126@students.mimuw.edu.pl)
 */
package cp2023.solution;

import java.util.HashMap;
import java.util.Map;

import cp2023.base.ComponentId;
import cp2023.base.DeviceId;
import cp2023.base.StorageSystem;
import cp2023.exceptions.DeviceDoesNotExist;



public final class StorageSystemFactory {

    // Static method to create a new StorageSystem
    public static StorageSystem newSystem(
            Map<DeviceId, Integer> deviceTotalSlots,
            Map<ComponentId, DeviceId> componentPlacement) {

        // Check if the provided maps are null
        if (deviceTotalSlots == null) {
            throw new IllegalArgumentException("Device total slots map cannot be null.");
        }
        if (componentPlacement == null) {
            throw new IllegalArgumentException("Component placement map cannot be null.");
        }

        // Check if the maps are empty
        if (deviceTotalSlots.isEmpty()) {
            throw new IllegalArgumentException("Device total slots map cannot be empty.");
        }

        // Check if all device capacities are positive numbers
        for (Integer capacity : deviceTotalSlots.values()) {
            if (capacity == null || capacity <= 0) {
                throw new IllegalArgumentException("Device capacities must be positive numbers.");
            }
        }

        // Check if each component is placed on an existing device
        for (Map.Entry<ComponentId, DeviceId> entry : componentPlacement.entrySet()) {
            DeviceId deviceId = entry.getValue();
            if (deviceId == null || !deviceTotalSlots.containsKey(deviceId)) {
                throw new IllegalArgumentException("Component placed on a non-existing or null device.");
            }
        }

        // Create a map to count the number of components per device
        Map<DeviceId, Integer> componentCountPerDevice = new HashMap<>();
        for (Map.Entry<ComponentId, DeviceId> entry : componentPlacement.entrySet()) {
            DeviceId deviceId = entry.getValue();
            if (deviceId != null) {
                componentCountPerDevice.put(deviceId, componentCountPerDevice.getOrDefault(deviceId, 0) + 1);
            }
        }

        // Check if any device is overloaded with too many components
        for (Map.Entry<DeviceId, Integer> entry : deviceTotalSlots.entrySet()) {
            DeviceId deviceId = entry.getKey();
            Integer totalSlots = entry.getValue();
            Integer placedComponents = componentCountPerDevice.getOrDefault(deviceId, 0);

            if (placedComponents > totalSlots) {
                throw new IllegalArgumentException("Too many components placed in device " + deviceId + ".");
            }
        }

        // Return a new instance of StorageSystem with the given configurations
        return new StorageSystemImpl(deviceTotalSlots, componentPlacement);
    }
}
